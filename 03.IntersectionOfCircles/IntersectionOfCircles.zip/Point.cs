﻿namespace _03.IntersectionOfCircles
{
    class Point
    {
        public int X, Y;

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
